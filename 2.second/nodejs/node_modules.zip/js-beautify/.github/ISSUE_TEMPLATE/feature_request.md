---
name: Feature request
about: You want new functionality added to the beautifier

---

# Description
> This is the default template for feature requests. 
>
> NOTE: 
> * Do not include screenshots! This library is a text processor, we need text inputs and outputs for debugging and fixing issues. 
> * Check the list of open issues before filing a new issue.


# Input
With this new feature, when I give like this input: 
```
<INSERT CODE HERE>
```

# Expected Output
I'd like to see this output:
```
<INSERT CODE HERE>
```

## Environment
OS:
